This is a website about owls being sky cats 
First time doing so, excuse the poor construction
Have a laugh and learn something maybe
Has all of the bog standard HTML and CSS elements you can play around with

